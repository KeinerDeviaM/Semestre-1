// Función para encontrar el número mayor entre tres números
function encontrarNumeroMayor() {
    var numero1 = parseFloat(prompt("Ingrese el primer número"));
    var numero2 = parseFloat(prompt("Ingrese el segundo número"));
    var numero3 = parseFloat(prompt("Ingrese el tercer número"));

    var numeroMayor;

    if (numero1 > numero2 && numero1 > numero3) {
        numeroMayor = numero1;
    } else if (numero2 > numero1 && numero2 > numero3) {
        numeroMayor = numero2;
    } else {
        numeroMayor = numero3;
    }

    document.write("El número mayor es: " + numeroMayor);
}

// Llamar a la función
encontrarNumeroMayor();
