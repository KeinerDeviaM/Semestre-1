let genero = prompt("Ingresa tu género: masculino/femenino").toLowerCase();
let edad = parseInt(prompt("Ingresa tu edad"));
let ayuda;

function definirGenero() {
    if (genero === "masculino") {
        ayuda = 40000;
        console.log("El valor de tu ayuda mensual es $" + ayuda);
    } else if (genero === "femenino") {
        if (edad > 50) {
            ayuda = 120000;
        } else if (edad >= 30 && edad <= 50) {
            ayuda = 100000;
        } else {
            ayuda = 0;
        }
    }
}

function mostrarAyuda() {
     if (ayuda > 0) {
         console.log("El valor de tu ayuda mensual es $" + ayuda);
     } else {
        console.log("No recibes ayuda mensual.");
     }
}

definirGenero();
mostrarAyuda();
