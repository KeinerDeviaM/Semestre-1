let fisica = parseInt (prompt ("Ingresa tu nota obtenida en fisica:  "));
let quimica = parseInt (prompt ("Ingresa tu nota obtenida en quimica: "));
let biologia = parseInt (prompt ("Ingresa tu nota obtenida en biologia: "));
let matematicas = parseInt (prompt ("Ingresa tu nota obtenida en matematicas: "));
let informatica = parseInt (prompt ("Ingresa tu nota obtenida en informatica: "));
let promedio;

function calcularPromedio(){
    promedio = fisica + quimica + biologia + matematicas + informatica/50* 10;
    if ( promedio <= 59 )
        console.log("Tu Promedio es : " + (promedio) +      " . Tu nota es mala");
    if ( promedio <= 60 > 80 )
        console.log("Tu Promedio es : " + (promedio) +      " . Tu nota es buena");
    if ( promedio > 80 )
        console.log("Tu Promedio es : " + (promedio) +      " . Tu nota es excelente");
}

calcularPromedio();