// Función para determinar el estado de la computadora
function verificarEstadoComputadora() {

    let emitePitido = prompt("¿La computadora emite un pitido al iniciarse? (si/no)").toLowerCase();
    let discoDuroGira = prompt("¿El disco duro gira? (si/no)").toLowerCase();

    if (emitePitido !== "si" && emitePitido !== "no") {
        console.log("Por favor, ingresa 'si' o 'no' para el pitido.");
        return;
    }
    if (discoDuroGira !== "si" && discoDuroGira !== "no") {
        console.log("Por favor, ingresa 'si' o 'no' para el disco duro.");
        return;
    }

   
    if (emitePitido === "si" && discoDuroGira === "si") {
        console.log("Póngase en contacto con el técnico apoyo");
    } else if (emitePitido === "si" && discoDuroGira === "no") {
        console.log("Verificar contactos de la unidad");
    } else if (emitePitido === "no" && discoDuroGira === "si") {
        console.log("Compruebe las conexiones de altavoces.");
    } else if (emitePitido === "no" && discoDuroGira === "no") {
        console.log ("Traiga lacomputadora para repararla en la central.");
    }
}


verificarEstadoComputadora();