// Función para calcular el costo de las copias impresas
function calcularCostoCopias() {
    let copias = parseInt(prompt("Inserte el número de copias que desea imprimir"));

    let costo;
    
    if (copias <= 499) {
        costo = 120;
        document.write("El valor de cada copia es de $120. ");
    } else if (copias > 499 && copias <= 750) {
        costo = 100;
        document.write("El valor de cada copia es de $100. ");
    } else if (copias >= 750 && copias <= 999) {
        costo = 80;
        document.write("El valor de cada copia es de $80. ");
    } else if (copias >= 1000) {
        costo = 60;
        document.write("El valor de cada copia es de $60. ");
    } else {
        document.write("Número de copias no válido.");
        return; // Salir de la función si el número de copias no es válido
    }

    let costoTotal = costo * copias;
    document.write("El costo total es de $" + costoTotal + ".");
}

// Llamar a la función
calcularCostoCopias();
