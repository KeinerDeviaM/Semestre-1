// Función para determinar si un número es par o impar
function verificarParImpar() {
    // Colocar un número cualquiera
    let numero = parseInt(prompt("Ingrese un número"));

    // Saber si es par o impar
    let par;
    let impar;

    // Calcular
    if (numero % 2 === 0) {
        par = true;
        impar = false;
    } else {
        par = false;
        impar = true;
    }

    // Mensaje
    document.write(`Su número es ${par ? "par" : "impar"}`);
}

// Llamar a la función
verificarParImpar();
