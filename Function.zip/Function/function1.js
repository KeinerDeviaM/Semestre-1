let nombre = prompt("Ingrese su nombre");
let tiempo = prompt("ingrese las horas trabajadas");

let tarifaHora;
let salario;

function DefinirTarifaHora(){
    if (tiempo <= 10) {
        tarifaHora = 30000;
    } else if (tiempo > 10) {
        tarifaHora = 33000;
    }
    return tarifaHora;
}

function CalcularSalario(){
    salario = tiempo * tarifaHora;
    console.log(`Señor/a ${nombre}, el número de horas es ${tiempo } y su salario equivale a ${salario}.`);
}

//Llamar a la funcion
DefinirTarifaHora();
CalcularSalario();