let tipoLavadora = prompt("Usaste la lavadora tipo 1 o 2");
let cantidad = parseInt(prompt("¿Cuántas lavadoras usarás?"));
let horas = parseInt(prompt("¿Cuántas horas las usaste?"));

let costoPorLavadora;

function DefinirCostoPorLavadora(){
    if (tipoLavadora === "1") {
        costoPorLavadora = 4000;
    } else if (tipoLavadora === "2") {
        costoPorLavadora = 3000;
    } else {
        console.log("Tipo de lavadora no válido.");
    }
}

function CalcularCostoTotal(){
    costoTotal = cantidad * horas * costoPorLavadora;
}

if (cantidad > 3) {
    costoTotal *= 0.97;
}

DefinirCostoPorLavadora();
CalcularCostoTotal();
console.log("Costo total por alquilar " + cantidad + " lavadoras tipo " + tipoLavadora + " por " + horas + " horas: " + costoTotal)



