let angulo1 = parseInt(prompt("Ingresa el angulo uno"));
let angulo2 = parseInt(prompt("Ingresa el angulo dos"));
let angulo3 = parseInt(prompt("Ingresa el angulo tres"));
let verificacion;

function calcularVerificacion(){
    verificacion = (angulo1+ angulo2 + angulo3);
    if (verificacion === 180 ) {
        console.log ("Tu triangulo si es valido")
    }else (verificacion !== 180 )
    {
        console.log ("Tu triangulo es invalido")
    }
}
calcularVerificacion();