// Arreglos para los nombres de los productos y las cantidades disponibles
let productos = ["Agua", "Refresco", "Snack", "Chips", "Galletas"];
let cantidades = [5, 3, 0, 2, 4]; // Cantidades iniciales de cada producto

// Función para mostrar el inventario
const mostrarInventario = () => {
    let inventario = "Inventario de productos:\n";
    for (let i = 0; i < productos.length; i++) {
        inventario += `${i + 1}. ${productos[i]} - Cantidad: ${cantidades[i]}\n`;
    }
    alert(inventario);
};

// Función para procesar el pago
const procesarPago = (codigo) => {
    if (codigo < 1 || codigo > productos.length) {
        alert("Código inválido. Por favor, elige un código de producto válido.");
        return false;
    }
    if (cantidades[codigo - 1] <= 0) {
        alert(`El producto ${productos[codigo - 1]} está agotado.`);
        sugerirProducto();
        return false;
    }
    // Aquí se simula que el usuario inserta una moneda de $1
    alert("Pago procesado. Producto entregado.");
    return true;
};

// Función para entregar el producto
const entregarProducto = (codigo) => {
    cantidades[codigo - 1]--; // Disminuir la cantidad del producto
    alert(`Has recibido: ${productos[codigo - 1]}.`);
};

// Función para sugerir otro producto disponible
const sugerirProducto = () => {
    for (let i = 0; i < cantidades.length; i++) {
        if (cantidades[i] > 0) {
            alert(`Te sugerimos el producto: ${productos[i]}.`);
            break;
        }
    }
};

// Menú principal
while (true) {
    mostrarInventario();
    let codigo = parseInt(prompt("Ingresa el código del producto (1-5) o 0 para salir:"));
    if (codigo === 0) {
        alert("Saliendo...");
        break;
    }
    if (procesarPago(codigo)) {
        entregarProducto(codigo);
    }
}
