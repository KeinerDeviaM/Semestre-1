// Arreglo para almacenar los nombres de los clientes en la cola
let cola = [];
const capacidadMaxima = 7;

// Función para agregar un cliente a la cola
const agregarCliente = (nombre) => {
    if (cola.length < capacidadMaxima) {
        cola.push(nombre);
        alert(`Cliente ${nombre} agregado a la cola.`);
    } else {
        alert("La cola está llena. No se pueden agregar más clientes.");
    }
};

// Función para atender al siguiente cliente
const atenderCliente = () => {
    if (cola.length > 0) {
        let clienteAtendido = cola.shift(); // Eliminar el primer cliente de la cola
        alert(`Atendiendo al cliente: ${clienteAtendido}`);
    } else {
        alert("No hay clientes en la cola para atender.");
    }
};

// Función para mostrar el estado de la cola
const mostrarCola = () => {
    if (cola.length > 0) {
        let estado = "Clientes en la cola:\n" + cola.join("\n");
        alert(estado);
    } else {
        alert("La cola está vacía.");
    }
};

// Menú principal
while (true) {
    let opcion = prompt("1. Agregar cliente\n2. Atender cliente\n3. Mostrar cola\n4. Salir\nElige una opción:");
    if (opcion === "1") {
        let nombre = prompt("Ingresa el nombre del cliente:");
        agregarCliente(nombre);
    } else if (opcion === "2") {
        atenderCliente();
    } else if (opcion === "3") {
        mostrarCola();
    } else if (opcion === "4") {
        alert("Saliendo...");
        break;
    } else {
        alert("Opción inválida.");
    }
}
