// Arreglo para las últimas 5 transacciones
let transacciones = [];
let saldo = 0;

// Función para mostrar el saldo actual
const consultarSaldo = () => {
    alert(`Saldo actual: $${saldo}`);
};

// Función para depositar dinero
const depositar = (monto) => {
    if (monto > 0) {
        saldo += monto;
        transacciones.push(monto);
        if (transacciones.length > 5) transacciones.shift(); // Mantener solo las últimas 5
        alert(`Depositaste: $${monto}. Saldo actual: $${saldo}`);
    } else {
        alert("El monto a depositar debe ser positivo.");
    }
};

// Función para retirar dinero
const retirar = (monto) => {
    if (monto > 500) {
        alert("No puedes retirar más de $500 en una sola transacción.");
    } else if (monto > saldo) {
        alert("Saldo insuficiente.");
    } else {
        saldo -= monto;
        transacciones.push(-monto);
        if (transacciones.length > 5) transacciones.shift(); // Mantener solo las últimas 5
        alert(`Retiraste: $${monto}. Saldo actual: $${saldo}`);
    }
};

// Función para mostrar las últimas transacciones
const mostrarTransacciones = () => {
    let historial = "Últimas transacciones:\n";
    transacciones.forEach((transaccion, index) => {
        historial += `Transacción ${index + 1}: ${transaccion > 0 ? "+" : ""}${transaccion}\n`;
    });
    alert(historial);
};

// Menú principal
while (true) {
    let opcion = prompt("1. Consultar saldo\n2. Depositar\n3. Retirar\n4. Mostrar transacciones\n5. Salir\nElige una opción:");
    if (opcion === "1") {
        consultarSaldo();
    } else if (opcion === "2") {
        let monto = parseFloat(prompt("Ingresa el monto a depositar:"));
        depositar(monto);
    } else if (opcion === "3") {
        let monto = parseFloat(prompt("Ingresa el monto a retirar:"));
        retirar(monto);
    } else if (opcion === "4") {
        mostrarTransacciones();
    } else if (opcion === "5") {
        alert("Saliendo...");
        break;
    } else {
        alert("Opción inválida.");
    }
}
