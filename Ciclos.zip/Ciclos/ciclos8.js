let continuar;

do {
    var dias = prompt("Ingrese el número de días que paga en el gimnasio:");

    if (dias === "90") {
        document.write("Su mensualidad es de 86000<br>");
    } else if (dias === "30") {
        document.write("Su mensualidad es de 35000<br>");
    } else if (dias === "15") {
        document.write("Su mensualidad es de 18000<br>");
    } else {
        document.write("Duración no válida. Por favor, selecciona 15, 30 o 90 días.<br>");
    }

    // Preguntar si quiere continuar
    continuar = prompt("¿Desea ingresar otro número de días? (si/no)").toLowerCase();
} while (continuar === "si");
