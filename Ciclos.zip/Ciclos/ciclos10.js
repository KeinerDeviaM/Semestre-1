let continuar;

do {
    let copias = parseInt(prompt("Inserte el número de copias que desea imprimir"));

    let costo;

    if (copias <= 499) {
        document.write("El valor de cada copia es de $120. ");
        costo = 120 * copias;
    } else if (copias > 499 && copias <= 750) {
        document.write("El valor de cada copia es de $100. ");
        costo = 100 * copias;
    } else if (copias >= 750 && copias <= 999) {
        document.write("El valor de cada copia es de $80. ");
        costo = 80 * copias;
    } else if (copias >= 1000) {
        document.write("El valor de cada copia es de $60. ");
        costo = 60 * copias;
    } else {
        document.write("Número de copias no válido. <br>");
    }

    document.write("El costo total es de $" + costo + "<br>");

    // Preguntar si quiere continuar
    continuar = prompt("¿Desea ingresar otro número de copias? (si/no)").toLowerCase();
} while (continuar === "si");
