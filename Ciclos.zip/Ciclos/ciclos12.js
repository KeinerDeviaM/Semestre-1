let continuar;

do {
    let modelo = prompt("Ingrese el modelo de su auto");

    switch (modelo) {
        case "119":
        case "179":
        case "189":
        case "195":
        case "221":
        case "780":
            document.write("El auto está defectuoso, llevar a garantía.<br>");
            break;
        default:
            document.write("Su auto no está defectuoso.<br>");
    }

    // Preguntar si quiere continuar
    continuar = prompt("¿Desea ingresar otro modelo de auto? (si/no)").toLowerCase();
} while (continuar === "si");
