let continuar;

do {
    // Coloque un número cualquiera
    let numero = parseInt(prompt("Ingrese un número"));

    // Saber si es par o impar
    let par;
    let impar;

    // Calcular
    if (numero % 2 == 0) {
        par = true;
        impar = false;
    } else {
        par = false;
        impar = true;
    }

    // Mensaje
    document.write(`Su número es ${par ? "par" : "impar"}<br>`);

    // Preguntar si quiere continuar
    continuar = prompt("¿Desea ingresar otro número? (si/no)").toLowerCase();
} while (continuar === "si");
