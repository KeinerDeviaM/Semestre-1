function calcularCostoCeluMovil() {
    var operador;
    var minutosInternacionales;

    // Solicitar y validar el operador
    do {
        operador = prompt("Seleccione su operador (Claro, Tigo, Movistar):").toLowerCase();
        if (operador !== "tigo" && operador !== "claro" && operador !== "movistar") {
            alert("Operador no válido. Por favor, elige entre Claro, Tigo o Movistar.");
        }
    } while (operador !== "tigo" && operador !== "claro" && operador !== "movistar");

    // Solicitar y validar la cantidad de minutos internacionales
    do {
        minutosInternacionales = parseInt(prompt("Ingrese la cantidad de minutos internacionales consumidos:"));
        if (isNaN(minutosInternacionales) || minutosInternacionales < 0) {
            alert("Por favor, ingresa un número válido de minutos (debe ser 0 o mayor).");
        }
    } while (isNaN(minutosInternacionales) || minutosInternacionales < 0);

    var cargoFijo, valorMinuto, valorPaqueteDatos;

    switch (operador) {
        case "tigo":
            cargoFijo = 45000;
            valorMinuto = 200;
            valorPaqueteDatos = 12000;
            break;
        case "claro":
            cargoFijo = 30000;
            valorMinuto = 100;
            valorPaqueteDatos = 18000;
            break;
        case "movistar":
            cargoFijo = 40000;
            valorMinuto = 250;
            valorPaqueteDatos = 8000;
            break;
    }

    var costoMinutos = minutosInternacionales * valorMinuto;
    var costoTotal = cargoFijo + costoMinutos;

    // Mostrar el resultado
    alert("El costo total para el operador " + operador.charAt(0).toUpperCase() + operador.slice(1) + " es: $" + costoTotal);
}

calcularCostoCeluMovil();
