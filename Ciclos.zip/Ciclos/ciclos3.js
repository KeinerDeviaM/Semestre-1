var tipoLavadora = prompt("Usaste la lavadora tipo 1 o 2");
var cantidad, horas;

do {
    cantidad = parseInt(prompt("¿Cuántas lavadoras usarás?"));
} while (cantidad === null || cantidad <= 0);

do {
    horas = parseInt(prompt("¿Cuántas horas las usaste?"));
} while (horas === null || horas <= 0);

var costoPorLavadora = (tipoLavadora === "1") ? 4000 : (tipoLavadora === "2") ? 3000 : null;

if (costoPorLavadora) {
    var costoTotal = cantidad * horas * costoPorLavadora;
    if (cantidad > 3) costoTotal *= 0.97; 

    alert("Costo total por alquilar " + cantidad + " lavadoras tipo " + tipoLavadora + " por " + horas + " horas: $" + costoTotal);
} else {
    alert("Tipo de lavadora no válido.");
}


