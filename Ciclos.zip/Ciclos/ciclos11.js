// Función para determinar el estado de la computadora
function verificarEstadoComputadora() {
    var emitePitido;
    var discoDuroGira;

    // Solicitar y validar si la computadora emite un pitido
    do {
        emitePitido = prompt("¿La computadora emite un pitido al iniciarse? (si/no)").toLowerCase();
        if (emitePitido !== "si" && emitePitido !== "no") {
            alert("Por favor, ingresa 'si' o 'no' para el pitido.");
        }
    } while (emitePitido !== "si" && emitePitido !== "no");

    // Solicitar y validar si el disco duro gira
    do {
        discoDuroGira = prompt("¿El disco duro gira? (si/no)").toLowerCase();
        if (discoDuroGira !== "si" && discoDuroGira !== "no") {
            alert("Por favor, ingresa 'si' o 'no' para el disco duro.");
        }
    } while (discoDuroGira !== "si" && discoDuroGira !== "no");

    // Determinar el estado de la computadora
    if (emitePitido === "si" && discoDuroGira === "si") {
        alert("Póngase en contacto con el técnico apoyo");
    } else if (emitePitido === "si" && discoDuroGira === "no") {
        alert("Verificar contactos de la unidad");
    } else if (emitePitido === "no" && discoDuroGira === "si") {
        alert("Compruebe las conexiones de altavoces.");
    } else if (emitePitido === "no" && discoDuroGira === "no") {
        alert("Traiga la computadora para repararla en la central.");
    }
}

verificarEstadoComputadora();
