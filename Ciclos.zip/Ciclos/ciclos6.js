let continuar;

do {
    var numero1 = prompt("Ingrese el primer número");
    var numero2 = prompt("Ingrese el segundo número");
    var numero3 = prompt("Ingrese el tercer número");

    var numeroMayor;

    // Convertir a números para la comparación
    numero1 = parseFloat(numero1);
    numero2 = parseFloat(numero2);
    numero3 = parseFloat(numero3);

    // Determinar el número mayor
    if (numero1 > numero2 && numero1 > numero3) {
        numeroMayor = numero1;
    } else if (numero2 > numero1 && numero2 > numero3) {
        numeroMayor = numero2;
    } else {
        numeroMayor = numero3;
    }

    document.write("El número mayor es: " + numeroMayor + "<br>");

    // Preguntar si quiere continuar
    continuar = prompt("¿Desea ingresar otros números? (si/no)").toLowerCase();
} while (continuar === "si");
