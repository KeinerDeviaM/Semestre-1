var nombre = prompt("Ingresa tu nombre: ");
var horas;

do {
    horas = prompt("Ingresa tus horas trabajadas: ");
    horas = parseInt(horas); // Convertir a número entero

    // Verificar si las horas son un número válido y no negativo
    if (horas === null || horas < 0) {
        alert("Por favor, ingresa un número válido de horas trabajadas.");
    }
} while (horas === null || horas < 0);

// Determinar la tarifa por hora
var tarifa = (horas <= 10) ? 3000 : 3300;

// Calcular el salario
var salario = horas * tarifa;

alert("Señor/a " + nombre + ", su número de horas es " + horas + " y su salario equivale a: $" + salario);
