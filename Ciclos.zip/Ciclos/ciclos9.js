var angulo1, angulo2, angulo3;
var verificacion;


do {
    angulo1 = parseInt(prompt("Ingresa el ángulo uno"));
} while (angulo1 <= 0);

do {
    angulo2 = parseInt(prompt("Ingresa el ángulo dos"));
} while (angulo2 <= 0);

do {
    angulo3 = parseInt(prompt("Ingresa el ángulo tres"));
} while (angulo3 <= 0);

verificacion = angulo1 + angulo2 + angulo3;


if (verificacion === 180) {
    alert("Tu triángulo sí es válido");
} else {
    alert("Tu triángulo es inválido");
}
