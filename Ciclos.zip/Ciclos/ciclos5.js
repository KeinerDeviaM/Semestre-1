var fisica, quimica, biologia, matematicas, informatica;

// Función para solicitar una nota válida
function solicitarNota(asignatura) {
    var nota;
    do {
        nota = parseInt(prompt("Ingresa tu nota obtenida en " + asignatura + ":"));
        // Validar que la nota sea un número entre 0 y 100
    } while (nota < 0 || nota > 100);
    return nota;
}

// Solicitar notas
fisica = solicitarNota("física");
quimica = solicitarNota("química");
biologia = solicitarNota("biología");
matematicas = solicitarNota("matemáticas");
informatica = solicitarNota("informática");

// Calcular el promedio
var promedio = (fisica + quimica + biologia + matematicas + informatica) / 5;

if (promedio <= 59) {
    alert("Tu porcentaje es: " + (promedio * 10) + ", tu nota es mala.");
} else if (promedio <= 60 >  80) {
    alert("Tu porcentaje es: " + (promedio * 10) + ", tu nota es buena.");
} else {
    alert("Tu porcentaje es: " + (promedio * 10) + ", tu nota es excelente.");
}
