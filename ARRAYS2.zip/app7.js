// Arreglo para almacenar los productos disponibles
const productos = [
    

];

// Arreglo para almacenar los productos en el carrito
let carrito = [];

// Función para agregar un producto al carrito
const agregarAlCarrito = (nombre, cantidad) => {
    const producto = productos.find(p => p.nombre === nombre);
    
    if (producto) {
        if (producto.stock >= cantidad) {
            // Verificar si el producto ya está en el carrito
            const productoEnCarrito = carrito.find(item => item.nombre === nombre);
            if (productoEnCarrito) {
                productoEnCarrito.cantidad += cantidad; // Incrementar la cantidad
            } else {
                carrito.push({ nombre: producto.nombre, precio: producto.precio, cantidad: cantidad });
            }
            producto.stock -= cantidad; // Reducir el stock del producto
            alert(`Agregado al carrito: ${cantidad} x ${producto.nombre}`);
        } else {
            alert("No hay suficiente stock disponible.");
        }
    } else {
        alert("Producto no encontrado.");
    }
};

// Función para mostrar el carrito de compras
const mostrarCarrito = () => {
    if (carrito.length > 0) {
        let estado = "Carrito de compras:\n";
        let totalCompra = 0;

        carrito.forEach(item => {
            const subtotal = item.precio * item.cantidad;
            estado += `${item.cantidad} x ${item.nombre} - Precio unitario: $${item.precio} - Subtotal: $${subtotal}\n`;
            totalCompra += subtotal;
        });

        estado += `Total de la compra: $${totalCompra}`;
        alert(estado);
    } else {
        alert("El carrito está vacío.");
    }
};

// Función para agregar un nuevo producto
const agregarProducto = (nombre, precio, stock) => {
    const productoExistente = productos.find(p => p.nombre === nombre);
    
    if (!productoExistente) {
        productos.push({ nombre, precio: parseFloat(precio), stock: parseInt(stock) });
        alert(`Producto agregado: ${nombre}, Precio: $${precio}, Stock: ${stock}`);
    } else {
        alert("El producto ya existe.");
    }
};

// Función para mostrar la lista de productos
const mostrarProductos = () => {
    if (productos.length > 0) {
        let listaProductos = "Lista de productos disponibles:\n";
        productos.forEach(producto => {
            listaProductos += `${producto.nombre} - Precio: $${producto.precio} - Stock: ${producto.stock}\n`;
        });
        alert(listaProductos);
    } else {
        alert("No hay productos disponibles.");
    }
};

// Menú principal
while (true) {
    let opcion = prompt("1. Agregar producto al carrito\n2. Mostrar carrito\n3. Agregar nuevo producto\n4. Mostrar lista de productos\n5. Salir\nElige una opción:");
    
    if (opcion === "1") {
        let nombreProducto = prompt("Ingresa el nombre del producto:");
        let cantidad = parseInt(prompt("Ingresa la cantidad a agregar:"));

        if (!isNaN(cantidad) && cantidad > 0) {
            agregarAlCarrito(nombreProducto, cantidad);
        } else {
            alert("Cantidad inválida.");
        }
    } else if (opcion === "2") {
        mostrarCarrito();
    } else if (opcion === "3") {
        let nombreNuevoProducto = prompt("Ingresa el nombre del nuevo producto:");
        let precioNuevoProducto = prompt("Ingresa el precio del nuevo producto:");
        let stockNuevoProducto = prompt("Ingresa la cantidad de stock del nuevo producto:");

        if (!isNaN(precioNuevoProducto) && !isNaN(stockNuevoProducto) && precioNuevoProducto > 0 && stockNuevoProducto > 0) {
            agregarProducto(nombreNuevoProducto, precioNuevoProducto, stockNuevoProducto);
        } else {
            alert("Precio o stock inválido.");
        }
    } else if (opcion === "4") {
        mostrarProductos();
    } else if (opcion === "5") {
        alert("Saliendo...");
        break;
    } else {
        alert("Opción inválida.");
    }
}
