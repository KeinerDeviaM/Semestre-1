// Arreglo para almacenar las citas programadas
let citas = [];

// Función para programar una cita
const programarCita = (nombrePaciente, fecha, hora, medico) => {
    const cita = {
        nombrePaciente,
        fecha: new Date(`${fecha}T${hora}`), // Crear un objeto de fecha
        medico
    };
    citas.push(cita);
    alert(`Cita programada para ${nombrePaciente} el ${fecha} a las ${hora} con el médico ${medico}.`);
};

// Función para ver todas las citas programadas
const verCitas = () => {
    if (citas.length > 0) {
        // Ordenar citas por fecha y hora
        citas.sort((a, b) => a.fecha - b.fecha);
        
        let listaCitas = "Citas programadas:\n";
        citas.forEach((cita, index) => {
            listaCitas += `${index + 1}. ${cita.nombrePaciente} - Fecha: ${cita.fecha.toLocaleDateString()} - Hora: ${cita.fecha.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - Médico: ${cita.medico}\n`;
        });
        alert(listaCitas);
    } else {
        alert("No hay citas programadas.");
    }
};

// Función para cancelar una cita
const cancelarCita = (indice) => {
    if (indice >= 1 && indice <= citas.length) {
        const citaCancelada = citas.splice(indice - 1, 1); // Eliminar la cita del arreglo
        alert(`Cita cancelada: ${citaCancelada[0].nombrePaciente} el ${citaCancelada[0].fecha.toLocaleDateString()} a las ${citaCancelada[0].fecha.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`);
    } else {
        alert("Índice de cita inválido.");
    }
};

// Menú principal
while (true) {
    let opcion = prompt("1. Programar cita\n2. Ver citas programadas\n3. Cancelar cita\n4. Salir\nElige una opción:");
    
    if (opcion === "1") {
        let nombrePaciente = prompt("Ingresa el nombre del paciente:");
        let fecha = prompt("Ingresa la fecha de la cita (YYYY-MM-DD):");
        let hora = prompt("Ingresa la hora de la cita (HH:MM):");
        let medico = prompt("Ingresa el nombre del médico:");

        programarCita(nombrePaciente, fecha, hora, medico);
    } else if (opcion === "2") {
        verCitas();
    } else if (opcion === "3") {
        let indiceCita = parseInt(prompt("Ingresa el número de la cita a cancelar:"));
        cancelarCita(indiceCita);
    } else if (opcion === "4") {
        alert("Saliendo...");
        break;
    } else {
        alert("Opción inválida.");
    }
}
