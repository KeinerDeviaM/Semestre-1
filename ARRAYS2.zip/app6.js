// Arreglo para almacenar la cola de espera
let colaDeEspera = [];
let contadorTurnos = 0;

// Función para tomar un turno
const tomarTurno = () => {
    contadorTurnos++;
    const numeroTurno = contadorTurnos; // Asignar un número único de turno
    colaDeEspera.push(numeroTurno);
    alert(`Turno tomado: ${numeroTurno}`);
};

// Función para llamar al siguiente cliente
const llamarCliente = () => {
    if (colaDeEspera.length > 0) {
        const turnoLlamado = colaDeEspera.shift(); // Elimina el primer turno de la cola
        alert(`Llamando al cliente con turno: ${turnoLlamado}`);
    } else {
        alert("No hay clientes en la cola de espera.");
    }
};

// Función para mostrar la cola de espera
const mostrarColaDeEspera = () => {
    if (colaDeEspera.length > 0) {
        let estado = "Cola de espera:\n" + colaDeEspera.join("\n");
        alert(estado);
    } else {
        alert("La cola de espera está vacía.");
    }
};

// Menú principal
while (true) {
    let opcion = prompt("1. Tomar un turno\n2. Llamar a un cliente\n3. Mostrar cola de espera\n4. Salir\nElige una opción:");
    
    if (opcion === "1") {
        tomarTurno();
    } else if (opcion === "2") {
        llamarCliente();
    } else if (opcion === "3") {
        mostrarColaDeEspera();
    } else if (opcion === "4") {
        alert("Saliendo...");
        break;
    } else {
        alert("Opción inválida.");
    }
}
