// Arreglo para almacenar los datos de los usuarios atendidos
let usuariosAtendidos = [];
const capacidadMaxima = 7;

// Función para agregar un usuario a la lista de atendidos
const agregarUsuario = (cedula, tipoAtencion) => {
    if (usuariosAtendidos.length < capacidadMaxima) {
        usuariosAtendidos.push({ cedula, tipoAtencion });
        alert(`Usuario con cédula ${cedula} agregado con tipo de atención: ${tipoAtencion}.`);
    } else {
        alert("La capacidad máxima de atención ha sido alcanzada.");
    }
};

// Función para atender al siguiente usuario
const atenderUsuario = () => {
    if (usuariosAtendidos.length > 0) {
        const usuarioAtendido = usuariosAtendidos.shift(); // Elimina el primer usuario de la lista
        alert(`Atendiendo al usuario: Cédula ${usuarioAtendido.cedula}, Tipo de atención: ${usuarioAtendido.tipoAtencion}`);
    } else {
        alert("No hay usuarios en la lista para atender.");
    }
};

// Función para mostrar las estadísticas de atención
const mostrarEstadisticas = () => {
    const totalUsuarios = usuariosAtendidos.length;
    const usuariosPorTipo = {
        llamada: 0,
        asesoriaEstudiante: 0,
        asesoriaDirectivo: 0,
        transferencia: 0,
    };

    usuariosAtendidos.forEach(usuario => {
        if (usuario.tipoAtencion === "llamada") {
            usuariosPorTipo.llamada++;
        } else if (usuario.tipoAtencion === "estudiante") {
            usuariosPorTipo.asesoriaEstudiante++;
        } else if (usuario.tipoAtencion === "directivo") {
            usuariosPorTipo.asesoriaDirectivo++;
        }
    });

    let estadisticas = `Total de usuarios atendidos: ${totalUsuarios}\n`;
    estadisticas += `Cantidad de usuarios por tipo:\n`;
    estadisticas += `- Llamada: ${usuariosPorTipo.llamada}\n`;
    estadisticas += `- Asesoría Estudiante: ${usuariosPorTipo.asesoriaEstudiante}\n`;
    estadisticas += `- Asesoría Directivo: ${usuariosPorTipo.asesoriaDirectivo}\n`;

    alert(estadisticas);
};

// Menú principal
while (true) {
    let opcion = prompt("1. Agregar usuario\n2. Atender usuario\n3. Mostrar estadísticas\n4. Salir\nElige una opción:");
    
    if (opcion === "1") {
        let cedula = prompt("Ingresa el número de cédula del usuario:");
        let tipoAtencion = prompt("Ingrese el tipo de atención (llamada/asesoria):").toLowerCase();

        if (tipoAtencion === "asesoria") {
            const tipoAsesoria = prompt("Ingrese el tipo de asesoría (estudiante/directivo):").toLowerCase();
            agregarUsuario(cedula, tipoAsesoria);
        } else if (tipoAtencion === "llamada") {
            agregarUsuario(cedula, "llamada");
        } else {
            alert("Tipo de atención inválido.");
        }
    } else if (opcion === "2") {
        atenderUsuario();
    } else if (opcion === "3") {
        mostrarEstadisticas();
    } else if (opcion === "4") {
        alert("Saliendo...");
        break;
    } else {
        alert("Opción inválida.");
    }
}
