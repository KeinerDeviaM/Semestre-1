// Función para determinar el estado de la computadora
function verificarEstadoComputadora() {
    
    var emitePitido = prompt("¿La computadora emite un pitido al iniciarse? (si/no)").toLowerCase();
    
    
    var discoDuroGira = prompt("¿El disco duro gira? (si/no)").toLowerCase();

    
    if (emitePitido !== "si" && emitePitido !== "no") {
        alert("Por favor, ingresa 'si' o 'no' para el pitido.");
        return;
    }
    if (discoDuroGira !== "si" && discoDuroGira !== "no") {
        alert("Por favor, ingresa 'si' o 'no' para el disco duro.");
        return;
    }

   
    if (emitePitido === "si" && discoDuroGira === "si") {
        alert("Póngase en contacto con el técnico apoyo");
    } else if (emitePitido === "si" && discoDuroGira === "no") {
        alert("Verificar contactos de la unidad");
    } else if (emitePitido === "no" && discoDuroGira === "si") {
        alert("Compruebe las conexiones de altavoces.");
    } else if (emitePitido === "no" && discoDuroGira === "no") {
        alert ("Traiga lacomputadora para repararla en la central.");
    }
}


verificarEstadoComputadora();