var fisica = parseInt (prompt ("Ingresa tu nota obtenida en fisica:  "));
var quimica = parseInt (prompt ("Ingresa tu nota obtenida en quimica: "));
var biologia = parseInt (prompt ("Ingresa tu nota obtenida en biologia: "));
var matematicas = parseInt (prompt ("Ingresa tu nota obtenida en matematicas: "));
var informatica = parseInt (prompt ("Ingresa tu nota obtenida en informatica: "));
var promedio = (fisica + quimica + biologia + matematicas + informatica/50)* 10  ;

if ( promedio <= 59 )
    alert ("Tu porcentaje es : " + (promedio) +      " tu nota es mala");
if ( promedio <= 60 > 80 )
    alert ("Tu porcentaje es : " + (promedio) +      " tu nota es buena");
if ( promedio > 80 )
    alert ("Tu porcentaje es : " + (promedio) +      " tu nota es exelente");
