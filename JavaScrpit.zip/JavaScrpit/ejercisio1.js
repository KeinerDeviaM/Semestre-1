var nombre = prompt (" Ingresa tu nombre: ")
var horas =  prompt (" Ingresa tus horas trabajadas: ")

if (horas <= 10 ) {
    alert (" Señor/a " + nombre + " su numero de horas es " + horas + " y su salaria equivale a : $" + horas*3000)
}

if (horas > 10 ) {
    alert (" Señor/a " + nombre + " su numero de horas es " + horas + " y su salaria equivale a : $" + horas*3300)
}