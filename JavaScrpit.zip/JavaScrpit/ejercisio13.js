function calcularCostoCeluMovil() {
    
    var operador = prompt("Seleccione su operador (Claro, Tigo, Movistar):").toLowerCase();
    
    
    var minutosInternacionales = parseInt(prompt("Ingrese la cantidad de minutos internacionales consumidos:"));

    
    var cargoFijo, valorMinuto, valorPaqueteDatos;

    
    switch (operador) {
        case "tigo":
            cargoFijo = 45000;
            valorMinuto = 200;
            valorPaqueteDatos = 12000;
            break;
        case "claro":
            cargoFijo = 30000;
            valorMinuto = 100;
            valorPaqueteDatos = 18000;
            break;
        case "movistar":
            cargoFijo = 40000;
            valorMinuto = 250;
            valorPaqueteDatos = 8000;
            break;
        default:
            alert("Operador no válido. Por favor, elige entre Claro, Tigo o Movistar.");
            return;
    }

    
    var costoMinutos = minutosInternacionales * valorMinuto;
    var costoTotal = cargoFijo + costoMinutos;

    // Mostrar el resultado
    alert("El costo total para el operador " + operador.charAt(0).toUpperCase() + operador.slice(1) + " es: $" + costoTotal);
}


calcularCostoCeluMovil();